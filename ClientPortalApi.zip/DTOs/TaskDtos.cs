namespace ClientPortalApi.DTOs
{
    public record CreateTaskDto(string Title, string? Description, DateTime? DueDate);
    public record UpdateTaskStatusDto(string Status);
}
