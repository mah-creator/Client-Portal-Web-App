namespace ClientPortalApi.Services
{
    public interface IProjectService
    {
        // placeholder - implement more methods as needed
    }
}
