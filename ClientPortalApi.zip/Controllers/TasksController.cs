using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using ClientPortalApi.Data;
using ClientPortalApi.Models;
using ClientPortalApi.DTOs;
using ClientPortalApi.Services;
using System.IdentityModel.Tokens.Jwt;
using System.Security.Claims;
using TaskStatus = ClientPortalApi.Models.TaskStatus;

namespace ClientPortalApi.Controllers
{
    [ApiController]
    [Route("api/projects/{projectId}/[controller]")]
    [Authorize]
    public class TasksController : ControllerBase
    {
        private readonly AppDbContext _db;
        private readonly INotificationService _notifications;
        public TasksController(AppDbContext db, INotificationService notifications) { _db = db; _notifications = notifications; }

        [HttpGet]
        public async Task<IActionResult> List(string projectId) {
            var tasks = await _db.TaskItems.Where(t => t.ProjectId == projectId).ToListAsync();
            return Ok(tasks);
        }

        [HttpPost]
        public async Task<IActionResult> Create(string projectId, [FromBody] CreateTaskDto dto) {
            var userId = User.FindFirstValue(ClaimTypes.NameIdentifier);
            var t = new TaskItem {
                ProjectId = projectId,
                CreatorId = userId,
                Title = dto.Title,
                Description = dto.Description,
                DueDate = dto.DueDate
            };
            _db.TaskItems.Add(t);
            await _db.SaveChangesAsync();

            await _notifications.NotifyProjectMembersAsync(projectId, $"{userId} created a task {t.Title}");
            return CreatedAtAction(nameof(Get), new { projectId = projectId, id = t.Id }, t);
        }

        [HttpGet("{id}")]
        public async Task<IActionResult> Get(string projectId, string id) {
            var t = await _db.TaskItems.FirstOrDefaultAsync(x => x.Id == id && x.ProjectId == projectId);
            if (t == null) return NotFound();
            return Ok(t);
        }

        [HttpPatch("{id}/status")]
        public async Task<IActionResult> UpdateStatus(string projectId, string id, [FromBody] UpdateTaskStatusDto dto) {
            var t = await _db.TaskItems.FirstOrDefaultAsync(x => x.Id == id && x.ProjectId == projectId);
            if (t == null) return NotFound();
            if (Enum.TryParse<TaskStatus>(dto.Status, out var st)) {
                t.Status = st;
                await _db.SaveChangesAsync();
                return Ok(t);
            }
            return BadRequest("Invalid status");
        }
    }
}
