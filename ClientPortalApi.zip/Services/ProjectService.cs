namespace ClientPortalApi.Services
{
    public class ProjectService : IProjectService
    {
        public ProjectService() { }
    }
}
