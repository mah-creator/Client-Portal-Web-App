namespace ClientPortalApi.DTOs
{
    public record LoginRequest(string Email, string Password);
    public record AuthResponse(string Token, DateTime ExpiresAt, string UserId, string Role);
}
