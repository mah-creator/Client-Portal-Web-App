namespace ClientPortalApi.Models
{
    public class Comment
    {
        public int Id { get; set; }
        public string UserId { get; set; } = null!;
        public string TaskId { get; set; } = null!;
        public string Body { get; set; } = null!;
        public DateTime CreatedAt { get; set; } = DateTime.UtcNow;
    }
}
